error('Automatic updates are currently disabled. Please see: https://github.com/plotly/MATLAB-Online for updates.');
